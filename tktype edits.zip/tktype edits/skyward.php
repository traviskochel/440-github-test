<!DOCTYPE HTML>
<html><head>
	<title>TK TYPE > Chartwell</title>
	
	<?php 
	
	 include('links_include.php');
	?>
	
	<script type="text/javascript">
	
	  var _gaq = _gaq || [];
	  _gaq.push(['_setAccount', 'UA-13075034-1']);
	  _gaq.push(['_trackPageview']);
	
	  (function() {
	    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
	    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
	    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
	  })();
	
	</script>
</head>
<body id="chartwell" class="interior">

	<div id="main-content" class="container">

		<?php 
		
		 include('header.php');
		?>
		
		
		
		<div id="right-col" class="grid_5 push_2">

		
			<div id="subnav">
				<h1>Skyward Sans Print</h1>	
				
				
			<div class="clearit"></div><!-- clearit -->

			</div><!-- subnav -->
			
			
			
			<div id="content">
				<div id="content-description" class="content-block skinnier-p">
					<p>Based on the alphabet found in Skyward Sword, the letterforms have been dramatically simplified in an effort to create a more balanced and readable typeface. The specimen translates to &lsquo;The Path Forward is not Always Straight Ahead&rsquo;. 					</p>
				
				

				</div><!-- content-description -->
				<div class="content-block">
					<h2 class="blank">&nbsp;</h2>
						<img src="images/chartwell/chartwell-pie-anim2.gif" alt="" class="anim" />
				</div><!--/.content-block -->
				
				<div class="content-block">
					<h2 id="buy" >Buy</h2>
					<ul id="skyward" class="clear-div" >
					
						<li><p>Hand pressed block print on  Kitakata paper. <br/>Signed and numbered edition of 19.</p>
							<p><a href="#" class="skyward">Add to cart $35 </a><em>(shipping included)</em></p>
						</li>
						
						
						
												
					</ul>
				
					<div class="skinnier-p">
						<h2>&nbsp;</h2>
						<p class="small-type">Orders are shipped via US Postal Service First Class Mail, packaged in a tube. Please contact us if you would prefer a flat shipment.
						</p>
						
					</div>
				</div>
			
			
			</div> <!-- content -->
		
		
		
	
	
	<?php
	
		include('footer.php');
	?>



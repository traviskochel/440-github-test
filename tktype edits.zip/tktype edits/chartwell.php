<!DOCTYPE HTML>
<html><head>
	<title>TK TYPE > Chartwell</title>
	
	<?php 
	
	 include('links_include.php');
	?>
	
	<script type="text/javascript">
	
	  var _gaq = _gaq || [];
	  _gaq.push(['_setAccount', 'UA-13075034-1']);
	  _gaq.push(['_trackPageview']);
	
	  (function() {
	    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
	    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
	    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
	  })();
	
	</script>
</head>
<body id="chartwell" class="interior">

	<div id="main-content" class="container">

		<?php 
		
		 include('header.php');
		?>
		
		
		
		<div id="right-col" class="grid_5 push_2">

		
			<div id="subnav">
				<h1>Chartwell</h1>	
				
				<ul>
					<li><a href="#buy" >Buy</a></li>
					<li><a href="#examples">Samples</a></li>
					<li><a href="#how">How to Use</a></li>
					<li><a href="#details">Technical Details</a></li>
					<li><a href="chartwell-web.php">Web Documentation</a></li>
					
				</ul>
			<div class="clearit"></div><!-- clearit -->

			</div><!-- subnav -->
			
			
			
			<div id="content">
				<div id="content-description" class="content-block skinnier-p">
					<p><em>Chartwell</em> is a tool for easily creating graphs in both web and print environments. In the format of a font, it utilizes OpenType to interpret and visualize the data. The data also remains editable, allowing for painless updates.
					</p>
				
				

				</div><!-- content-description -->
				<div class="content-block">
					<h2 class="blank">&nbsp;</h2>
						<img src="images/chartwell/chartwell-pie-anim2.gif" alt="" class="anim" />
				</div><!--/.content-block -->
				
				<div class="content-block">
					<h2 id="buy" >Buy</h2>
					<p>The <em>Chartwell</em> family, including four new styles, is currently transitioning to the <a href="http://www.fontfont.com/">FontFont</a> library. Licenses will be available again shortly.
					</p>
					<ul id="chartwellcomplete" class="buy-form clear-div" >
					
						<li id="chartwellpies"><img src="images/chartwell/chartwell-pies-buy.png" alt="Chartwell Pies"/>
							
						</li>
						
						<li id="chartwellbars"><img src="images/chartwell/chartwell-bars-buy.png" alt="Chartwell Bars"/>
							
						</li>
						
						<li id="chartwelllines"><img src="images/chartwell/chartwell-lines-buy.png" alt="Chartwell Lines"/>
									
						</li>
						
												
					</ul>
				
				
				</div>
			
				
				
						
					<div id="examples" class="content-block">
						
						<h2>Chartwell Pies</h2>
							<img src="images/chartwell/chartwell-pies-ex1.png" alt="Chartwell Pies" />
							
							
							
						
						<h2>Chartwell Bars</h2>
							<img src="images/chartwell/chartwell-bars-ex1.png" alt="Chartwell Bars"  />
							
						
						<h2>Chartwell Lines</h2>
						<img src="images/chartwell/chartwell-lines-ex1.png" alt="Chartwell Lines" />
						
						<h2>Supporting Alphabet</h2>
						<img src="images/chartwell/chartwell-text-ex1.png" alt="Chartwell Supporting Alphabet" />
					</div><!-- /#examples -->
					
					<div id="how" class="content-block skinnier-p">
						<h2>How to Use</h2>
						
						<h3>Basics</h3>
						<p>1: Turn all ligatures off, and make sure 
						the tracking is set to &ldquo;0&rdquo;.
						</p>
						
						<p>2: Type values. Use &ldquo;+&rdquo; to connect values into the same chart.
						</p>
					
						<p>3: Adjust colors if desired.
						</p>
						
						<p>4: Turn standard ligatures on, and enjoy!
						</p>
						<h3>Pies Specifics</h3>
						<p>Supports whole number values from 1-100. If the total is greater than 100, a new chart will begin. The letters a-Z create various sized circles that center over the chart, and can be used transform the chart into a ring.
						 
						</p>
						<h3>Bars Specifics</h3>
						<p>Supports whole number values from 1-1,000. There is no limit to the number of stacked values. Values can be stacked to visualize values larger than 1,000. Use &ldquo;=&rdquo; to put a top on the bar.
						</p>
						
						<h3>Lines Specifics</h3>
						<p>Supports whole number values from 1-100. If values greater than 100 are needed, stretch the font vertically. If stretched 200%, all values will appear at twice their value. Be aware, the more a font is stretched, the coarser the increment between values becomes.
						</p>
						
						
							
						
						
					</div><!-- /#how -->
										
					
					<div id="details" class="content-block">
						<h2>Technical Details</h2> 
							
							<div class="grid_3 first">
								<p><a href="downloads/Chartwell-TKTYPE.pdf" target="_blank">PDF Specimen</a><br/>
								<a href="downloads/tktypeEULAv3.0.pdf" target="_blank">License Agreement</a><br/></p>
								<p>	
								Designer: Travis Kochel<br/>
								Released: 2011<br />
								Number of glyphs per style: Up to 10,000
								</p>
								
								
								<h3>Hinting and the Web</h3>
									<p>@font-face embedding is allowed. These fonts contain PostScript hints only. Be sure to test in all targeted browsers. Check the <a href="chartwell-web-browsers.php">browser samples</a> before purchasing for uses on the web. 
									</p>
									<p>Until there is better support for opentype in browsers, all licenses come with a javascript plugin to do the heavy lifting. 
									</p>
									<p><a href="chartwell-web.php" >Details and Documentation</a>
									</p>
								<h3 id="issues">Known Issues</h3>
								<p>Sometimes screen rendering of the live font file can produce artifacts as seen <a href="#" class="popup-start">here<img src="images/chartwell/chartwell-lines-artifacts2.png" class="popup" /></a>. These do not show up in printed files, or when saved as a rasterized image format(ie. png, gif, jpg, tif). If consistency is needed for viewing on screen in vector format, consider converting the text to outlines.
								 
								</p>
								<p>On Mac OSX 10.5 and below, applications that rely on the Mac text engine, such as TextEdit, Omnigraffle and iWork are not able to render <em>Chartwell.</em> Adobe Illustrator, InDesign and Photoshop have their own text engine and are not affected by this issue. 
								</p>
								<p>
									On Mac OSX 10.6 TextEdit and Omnigraffle work, however, the issue is still unresolved in iWork applications.
								</p>
								<p>
									Microsoft Office does not like <em>Chartwell</em> either, but Excel is probably better suited for those environments.
								</p>
								<p>If you have questions about support in a specific environment, or find a bug, please email me at <a href="mailto:info@tktype.com">info@tktype.com</a>.
									
								</p>
							</div><!-- grid2 -->	
							<div class="grid_2">
								<h3>OpenType Features</h3>
									<p>Ligatures <em>(required)</em>
									</p>		
								<h3>Language Coverage</h3>  
									Only basic numerals, alphabet and punctuation, to aid in preparing the information, have been included.
								
								<h3>The Name</h3>  
									Taken from a Wellington street named &ldquo;Chartwell&rdquo;. 
							</div><!-- /.grid3 --> 
							
							
							<div class="clearit"></div><!-- clearit -->
					</div><!-- /#details -->
			
			</div> <!-- content -->
		
		
		
	
	
	<?php
	
		include('footer.php');
	?>


